This module restores the ``case_default`` fields to Project Tasks and project
stage tab, removed in Odoo 9.0 and later.
