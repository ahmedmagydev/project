from odoo import models, fields, api, _
from odoo.exceptions import UserError


class Project(models.Model):
    _inherit = "project.project"

    @api.model
    def create(self, vals):
        if self.env.user.has_group('eg_project_creation_restriction.project_creation_restriction'):
            raise UserError(_("You don't have access to create Project."))
        else:
            return super(Project, self).create(vals)
