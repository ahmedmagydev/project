To use this module, you need to:

#. Activate the subtasks for each project record individually
#. Select the filter or the filter group Parent tasks in a Project
