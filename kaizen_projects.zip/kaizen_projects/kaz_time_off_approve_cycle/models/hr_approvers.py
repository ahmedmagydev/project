# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class HrApprovers(models.Model):
    _name = 'hr.approvers.lines'
    _description = 'Hr Approvers '

    time_off_id = fields.Many2one('hr.leave', string='Time Off')
    manager_id = fields.Many2one('hr.employee', string='Manager')
    approved = fields.Boolean()

