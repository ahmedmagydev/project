# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class HrLeave(models.Model):
    _inherit = 'hr.leave'

    is_confirmed = fields.Boolean()
    is_next_approve = fields.Boolean(compute='_compute_is_next_approve', readonly=0)

    def _compute_is_next_approve(self):
        """
                Compute the next approver for the current record.
                This function checks if the current record is ready for approval and determines
                the next approver based on certain conditions. It returns a dictionary with the
                key 'Main' if the main manager is the next approver or 'Lines' if the line manager
                is the next approver. The dictionary also includes the respective manager(s)
                depending on the key.
                :return: A dictionary with the key 'Main' or 'Lines' and the respective manager(s).
                :rtype: dict
                """
        for rec in self:
            approver = rec.holiday_status_id.lines_ids.filtered(lambda x: x.approved == False)
            leave_manager_approver = rec.employee_ids[0].leave_manager_id
            employee_time_off_lines = leave_manager_approver.employee_id.hr_approvers_lines_ids.filtered(
                lambda x: x.time_off_id.id == rec.id and x.approved == True)
            ''' First Approver '''
            if rec.employee_ids and rec.env.user.id == leave_manager_approver.id and rec.is_confirmed == False:
                if not employee_time_off_lines:
                    rec.is_next_approve = True
                    rec.message_post(body=f"{leave_manager_approver.employee_id.name} Approve Done ")
                    return {'key': 'Main', 'manager': leave_manager_approver.employee_id}
            elif approver and approver[0].manager_id.user_id.id == rec.env.user.id and rec.is_confirmed == False:
                time_off_line = approver[0].manager_id.hr_approvers_lines_ids.filtered(
                    lambda x: x.time_off_id.id == rec.id and x.approved == True)
                if rec.employee_ids and employee_time_off_lines:
                    if not time_off_line:
                        rec.is_next_approve = True
                        return {'key': 'Lines', 'manager': approver[0].manager_id, 'line': approver}
            else:
                rec.is_next_approve = False

    def action_approve_cycle(self):
        """
         Create an approval cycle for the current time off request.
         This function creates an approval cycle for the current time off request by determining the next
         approver and adding an entry to the 'hr.approvers.lines' table with the following information:
         - 'time_off_id': the ID of the current time off request.
         - 'manager_id': the ID of the next approver.
         - 'approved': True (indicating that the time off request has been approved).
         After creating the approval cycle, the function updates the 'is_next_approve' field of the current
         time off request to False.
         If the 'manager' variable contains a 'line' key and its corresponding value is 'Lines', the function
         sets the 'approved' attribute of the first line in the 'line' list to True. If the length of the 'line'
         list is equal to 1, the function sets the 'is_confirmed' field of the current time off request to True
         and calls the 'action_approve' method. Otherwise, the function posts a message with the content
         "{manager['manager'].name} Approve Done ".
         Parameters:
         - None
         Returns:
         - None
         """
        manager = self._compute_is_next_approve()
        self.env['hr.approvers.lines'].sudo().create({
            'time_off_id': self.id,
            'manager_id': manager['manager'].id,
            'approved': True
        })
        self.is_next_approve = False

        if 'line' in manager and manager['key'] == 'Lines':
            manager['line'][0].approved = True
            message = self.message_post(body=f"{manager['manager'].name} Approve Done ")
            if len(manager['line']) == 1:
                self.is_confirmed = True
                self.action_approve()
                return message
            else:
                return message
