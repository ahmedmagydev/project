# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class HrLeaveType(models.Model):
    _inherit = 'hr.leave.type'

    manager_id = fields.Many2one('hr.employee', string='Manager')
    can_approve = fields.Boolean()
    lines_ids = fields.One2many(
        comodel_name='leave.type.lines',
        inverse_name='type_id',
        string='Lines_idas',
        required=False)


class Lines(models.Model):
    _name = 'leave.type.lines'

    char = fields.Char(
        string='Char',
        required=False)
    department_id = fields.Many2one(
        comodel_name='hr.department',
        string='Department',
        required=False)
    manager_id = fields.Many2one(
        comodel_name='hr.employee',
        string='Manager',
        required=False, related='department_id.manager_id')
    approved = fields.Boolean(
        string='Approved',
        required=False)
    type_id = fields.Many2one(
        comodel_name='hr.leave.type',
        string='Type_id',
        required=False)