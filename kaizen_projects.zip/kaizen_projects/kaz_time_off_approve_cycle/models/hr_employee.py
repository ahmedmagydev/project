# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    hr_approvers_lines_ids = fields.One2many('hr.approvers.lines', 'manager_id', string='Approver Lines')
