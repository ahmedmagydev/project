# -*- coding: utf-8 -*-

from . import hr_leave
from . import hr_employee
from . import hr_leave_type
from . import hr_approvers

