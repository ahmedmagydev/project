* Alexandre Moreau <alexandre.moreau@doscaal.fr>
* Dennis Sluijk <d.sluijk@onestein.nl>
* Nikul Chaudhary <nikulchaudhary2112@gmail.com>
* Eduardo Magdalena <emagdalena@c2i.es> (C2i Change 2 improve http://www.c2i.es)

* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Carlos Dauden
  * Alexandre Díaz

* `Open Source Integrators <https://www.opensourceintegrators.com>`_:

  * Daniel Reis <dreis@opensourceintegrators.com>
