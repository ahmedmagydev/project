Website HelpDesk Dashboard
==========================

Helps in the Complete analysis of helpdesk support module.

Depends
=======
[odoo_website_helpdesk] Custom addon by Cybrosys.

Tech
====
* [Python] - Models
* [XML] - Odoo views

Installation
============
- www.odoo.com/documentation/16.0/setup/install.html

- Install our custom addon


Credits
=======
* Cybrosys Techno Solutions <https://www.cybrosys.com>

Author
------

Developer( Version 16): Robin K, odoo@cybrosys.com
Contact: odoo@cybrosys.com


Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.openhrms.com

