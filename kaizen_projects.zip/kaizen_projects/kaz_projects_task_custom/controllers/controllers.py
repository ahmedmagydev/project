# -*- coding: utf-8 -*-
# from odoo import http


# class KazProjectsTaskCustom(http.Controller):
#     @http.route('/kaz_projects_task_custom/kaz_projects_task_custom', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/kaz_projects_task_custom/kaz_projects_task_custom/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('kaz_projects_task_custom.listing', {
#             'root': '/kaz_projects_task_custom/kaz_projects_task_custom',
#             'objects': http.request.env['kaz_projects_task_custom.kaz_projects_task_custom'].search([]),
#         })

#     @http.route('/kaz_projects_task_custom/kaz_projects_task_custom/objects/<model("kaz_projects_task_custom.kaz_projects_task_custom"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('kaz_projects_task_custom.object', {
#             'object': obj
#         })
