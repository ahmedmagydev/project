from odoo import models, fields, api


class ProjectTaskCategories(models.Model):
    _name = 'project.task.categories'
    _description = 'Task Categories'

    name = fields.Char('Name', help='Category Name')
    sequence = fields.Integer('Sequence', default=0, help='Sequence')
