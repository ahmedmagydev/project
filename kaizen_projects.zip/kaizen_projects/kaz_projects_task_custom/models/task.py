from odoo import api, fields, models, exceptions, Command

PRIORITIES = [
    ('0', 'Very Low'),
    ('1', 'Low'),
    ('2', 'Mid'),
    ('3', 'High'),
    ('4', 'Very High'),
]


class Task(models.Model):
    _inherit = 'project.task'
    _rec_name = 'task_sequence'

    task_sequence = fields.Char(string="Task Sequence", readonly=True, copy=False, default="New")
    phone = fields.Char('Phone Number', help='Phone Number')
    priority = fields.Selection(PRIORITIES, default='1', help='Priority of the Ticket')
    accept_task=fields.Char(string="Accept Task")  
    accept_test=fields.Char(string="Accept Test")                                                        
    expected_houres = fields.Float(string="Expected Hours")
    actual_houres= fields.Float(string="Actual Hours")
    create_date = fields.Datetime('Creation Date', help='Created date')
    start_date = fields.Datetime('Start Date', help='Start Date',required=True)
    end_date = fields.Datetime('End Date', help='End Date')
    last_updated_date = fields.Datetime('Last Updated Date', help='Last Updated Date')
    replied_date = fields.Datetime('Replied Date', help='Replied Date')

    product_id = fields.Many2one('product.template', 'Product')

    team_id = fields.Many2one('project.team', 'Team')
    team_lead_id = fields.Many2one('res.users', 'Team Leader', related='team_id.team_lead_id')

    requirement_video = fields.Binary('Requirement Video', help='Requirement Video')
    delivered_video = fields.Binary('Delivered Video', help='Delivered Video')
    testing_link = fields.Char('Testing Attachment Link', help='Put your Drive link which contains the video')
    requirement_link = fields.Char('Requirement Attachment Link', help='Put your Drive link which contains the video')
    delivered_link = fields.Char('Delivered Attachment Link', help='Put your Drive link which contains the video')
    is_requirement_video_required = fields.Boolean(
        string="Is Requirement Video Required",
        default=False,
        store=True,
    )

    is_delivered_video_required = fields.Boolean(
        string="Is Delivered Video Required",
        default=False,
        store=True,
    )

    is_testing_link_required = fields.Boolean(
        string="Is Testing Attachment Required",
        default=False,
        store=True,
    )
    is_todo=fields.Boolean(string="is todo" ,default=False,store=True) 

    is_required = fields.Boolean(
        default=False,
        store=True
    )

    question_ids = fields.One2many('task.question', 'task_id', 'Questions')
    
    @api.onchange('stage_id')
    def _onchange_requirement_video_required(self):
        for task in self:
            if task.stage_id.name == 'Note' or 'New' or 'In_Progress':
                task.is_requirement_video_required = True
            else:
                task.is_requirement_video_required = False

    @api.onchange('stage_id')
    def _onchange_delivered_video_required(self):
        for task in self:
            if task.stage_id.name == 'Done':
                task.is_delivered_video_required = True
            else:
                task.is_delivered_video_required = False

    @api.onchange('stage_id')
    def _onchange_testing_link_required(self):
        for task in self:
            if task.stage_id.name == 'Testing':
                task.is_testing_link_required = True
            else:
                task.is_testing_link_required = False
    @api.onchange('stage_id')
    def _onchange_is_todo(self):
        for task in self:
            if task.stage_id.name == 'To Do':
                task.is_todo = True
            else:
                task.is_todo = False                

    @api.model
    def create(self, vals):
        print(f"Creating task with values: {vals}")
        if vals.get('task_sequence', 'New') == 'New':
            vals['task_sequence'] = self.env['ir.sequence'].next_by_code('project.task.sequence') or 'New'

        task = super(Task, self).create(vals)
        task._onchange_requirement_video_required()
        task._onchange_delivered_video_required()
        task._onchange_testing_link_required()
        print(f"Task created with ID: {task.id}")
        return task

    def write(self, values):
        if 'stage_id' in values:
            for task in self:
                task.update_start_end_dates()
                if task.stage_id in values:
                    values['is_requirement_video_required'] = task.stage_id.name in ['Note', 'New', 'In_Progress']
                    values['is_delivered_video_required'] = task.stage_id.name == 'Done'
                    values['is_testing_link_required'] = task.stage_id.name == 'Testing'

        if 'stage_id' in values:
            today = fields.Datetime.now()
            for task in self:
                stage_name = task.env['project.task.type'].browse(values['stage_id']).name
                if stage_name == 'In_Progress':
                    values['start_date'] = today
                elif stage_name == 'Done':
                    values['end_date'] = today
        if values:
            values['last_updated_date'] = fields.Datetime.now()
        task = super(Task, self).write(values)
        return task

    def update_start_end_dates(self):
        for task in self:
            if task.stage_id and task.stage_id.name == 'In_Progress':
                task.start_date = fields.Datetime.now()
               
            elif task.stage_id and task.stage_id.name == 'Done':
                task.end_date = fields.Datetime.now()
