from odoo import models, fields, api


class ProjectTaskTypes(models.Model):
    _name = 'project.task.types'
    _description = 'Task Types'

    name = fields.Char(string='Type', help='Types')
