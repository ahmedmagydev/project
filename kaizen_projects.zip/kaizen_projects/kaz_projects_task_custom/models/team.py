from odoo import api, fields, models


class ProjectTeam(models.Model):
    _name = 'project.team'
    _description = 'Project Team'

    name = fields.Char('Name', help='Helpdesk Team Name')
    team_lead_id = fields.Many2one('res.users', string='Team Leader',
                                   help='Team Leader Name',
                                   domain=lambda self: [
                                       ('groups_id', 'in', self.env.ref(
                                           'project.group_project_manager').id)])
    member_ids = fields.Many2many('res.users', string='Members',
                                  help='Team Members',
                                  domain=lambda self: [
                                      ('groups_id', 'in', self.env.ref(
                                          'project.group_project_user').id)])
    email = fields.Char('Email', help='Email')
    project_id = fields.Many2one('project.project',
                                 string='Project',
                                 help='Projects')
    create_task = fields.Boolean(string="Create Task",
                                 help="Task created or not")

    @api.onchange('team_lead_id')
    def members_choose(self):
        """Members selection function"""
        fetch_memebers = self.env['res.users'].search([])
        filterd_members = fetch_memebers.filtered(
            lambda x: x.id != self.team_lead_id.id)
        return {'domain': {'member_ids':
                               [('id', '=', filterd_members.ids), (
                               'groups_id', 'in',
                               self.env.ref('base.group_user').id),
                                ('groups_id', 'not in', self.env.ref(
                                    'project.group_project_manager').id)]}}