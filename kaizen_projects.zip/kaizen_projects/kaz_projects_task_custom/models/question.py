from odoo import api, fields, models, exceptions, Command


class TaskQuestion(models.Model):
    _name = 'task.question'

    question_description = fields.Char(string='Note')
    question_content_id = fields.Many2one('task.question.content', 'Question')
    question_answer = fields.Char(string='Answer', )
    task_id = fields.Many2one('project.task', 'Task')
