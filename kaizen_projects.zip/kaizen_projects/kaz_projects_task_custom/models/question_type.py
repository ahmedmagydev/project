from odoo import api, fields, models, exceptions, Command


class TaskQuestionContent(models.Model):
    _name = 'task.question.content'
    _rec_name = 'content'

    content = fields.Char(string='Question')
